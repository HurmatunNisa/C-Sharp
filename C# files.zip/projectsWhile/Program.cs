﻿// See https://aka.ms/new-console-template for more information
using static System.Console;

/*bool condition=false;
int result=0;
WriteLine("Enter an integer between 5 and 10 : ");
do
{
    string? number= ReadLine();
    bool decide = int.TryParse(number,out result);
    if (decide)
    {
        if (result>=5 && result<=10)
        {
            WriteLine($"Your input value ({result}) has been accepted.");
            condition=true;
        }
        else
        {
            WriteLine($"You entered {result}. Please enter a number between 5 and 10.");
            continue;
        }
    }
    else
        WriteLine("Sorry, you entered an invalid number, please try again");
        continue;

    //WriteLine(decide);

} while (!condition);*/

string[] myStrings = new string[2] { "I like pizza. I like roast chicken. I like salad", "I like all three of the menu choices" };
int stringsCount = myStrings.Length;

string myString = "";
int periodLocation = 0;

for (int i = 0; i < stringsCount; i++)
{
    myString = myStrings[i];
    periodLocation = myString.IndexOf(".");

    string mySentence;

    // extract sentences from each string and display them one at a time
    while (periodLocation != -1)
    {

        // first sentence is the string value to the left of the period location
        mySentence = myString.Remove(periodLocation);

        // the remainder of myString is the string value to the right of the location
        myString = myString.Substring(periodLocation + 1);

        // remove any leading white-space from myString
        myString = myString.TrimStart();

        // update the comma location and increment the counter
        periodLocation = myString.IndexOf(".");

        Console.WriteLine(mySentence);
    }
 
    mySentence = myString.Trim();
    Console.WriteLine(mySentence);
}
 