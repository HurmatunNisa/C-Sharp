﻿// See https://aka.ms/new-console-template for more information

using static System.Console;

/*WriteLine("a" == "a");
WriteLine("a" == "A");
WriteLine(1 == 2);

string myValue = "a";
WriteLine(myValue == "a");




int am = 10000;
WriteLine(am>1000?100:50);

Random coin = new Random();
int flip = coin.Next(1,3);
WriteLine("Coin Flip Result : " + (flip) == 1 ? "head": "tail"  );





string output="";

string permission = "Admin|Manager";
int level = 55;
if(permission.ToLower().Contains("admin"))
{
    if(level>55)
      output="Welcome, Super Admin user.";
    
    else if(level<=55)
      output="Welcome, Admin user.";
}
else if(permission.ToLower().Contains("manager"))
{
     if(level>20)
      output="Contact an Admin for access.";
    
    else if(level<=20)
      output="You do not have sufficient privileges.";

}
else if(!permission.ToLower().Contains("manager") | !permission.ToLower().Contains("admin"))
{
    output="You do not have sufficient privileges.";
}

WriteLine(output);*/



int[] numbers = { 4, 8, 15, 16, 23, 42 };
int total=0;
bool found = false;
foreach (int number in numbers)
{
    total += number;
    if (number == 42)
       found = true;
}
if (found) 

    Console.WriteLine("Set contains 42");

Console.WriteLine($"Total: {total}");

