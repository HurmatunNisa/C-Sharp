﻿// See https://aka.ms/new-console-template for more information
using static System.Console;


/*Pet ID #.
Pet species (cat or dog).
Pet age (years).
A description of the pet's physical condition/characteristics.
A description of the pet's personality.
The pet's nickname.*/