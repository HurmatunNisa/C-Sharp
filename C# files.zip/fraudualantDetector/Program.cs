﻿// See https://aka.ms/new-console-template for more information
//string[] fraudulentOrderID = new string[3];
 
/*fraudulentOrderID[0] = "A123";
fraudulentOrderID[1] = "B456";
fraudulentOrderID[2] = "C789";
fraudulentOrderID[3] = "D000";*

string[] fraudulentOrderID = { "B123", "C234", "A345" ,"C15", "B177", "G3003" , "C235", "B179"};

foreach (string item in fraudulentOrderID)
{
    if (item.StartsWith("B"))
    {
        Console.WriteLine($"The order {item} starts with B");
    }
}
*/

/*
  The following code creates five random OrderIDs
  to test the fraud detection process.  OrderIDs 
  consist of a letter from A to E, and a three
  digit number. Ex. A123.
*
Random random = new Random();
string[] orderIDs = new string[5];

for (int i = 0; i < orderIDs.Length; i++)
{
    int prefixValue = random.Next(65, 70);
    Console.WriteLine(prefixValue);
    string prefix = Convert.ToChar(prefixValue).ToString();
    Console.WriteLine(prefix);
    string suffix = random.Next(1, 1000).ToString("000");
    Console.WriteLine(suffix);

    orderIDs[i] = prefix + suffix;
}

foreach (var orderID in orderIDs)
{
    Console.WriteLine(orderID);
}*/

string str = "The quick brown fox jumps over the lazy dog.";
// convert the message into a char array
char[] charMessage = str.ToCharArray();
// Reverse the chars
Array.Reverse(charMessage);
int x = 0;
// count the o's
foreach (char i in charMessage) { if (i == 'o') { x++; } }
// convert it back to a string
string new_message = new String(charMessage);
// print it out
Console.WriteLine(new_message);
Console.WriteLine($"'o' appears {x} times.");